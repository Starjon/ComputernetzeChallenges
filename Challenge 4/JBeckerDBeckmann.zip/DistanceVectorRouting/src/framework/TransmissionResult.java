package framework;

public enum TransmissionResult {
    Success,
    DestinationUnreachable,
    Failure
}
